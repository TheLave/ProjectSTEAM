import json
import urllib.request
import RPi.GPIO as GPIO
import time
GPIO.setmode( GPIO.BCM )
GPIO.setwarnings( 0 )

shift_clock_pin = 5
latch_clock_pin = 6
data_pin = 13

#377160
#413150
#250900
#406150


with urllib.request.urlopen("http://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/?appid=406150&key=248E21AEC4B9E0FA386209D67BF7AC5F&steamid=76561198185415022") as url:
    rawData = json.loads(url.read().decode())
    data = rawData["playerstats"]['achievements']
    spel = rawData["playerstats"]['gameName']
    print('Spel: ' + spel)
    print('Aantal achievements: ' + str(len(data)))

aantal = len(data)
keer = 1
aantalLampjes = -1
compleet = 0

for achievements in data:

    if achievements['achieved'] == 1:

        compleet += 1


print('aantal achievements behaald: ' + str(compleet))


while aantalLampjes == -1:
    if ((aantal/8) * keer) < compleet and keer < 8:
        keer += 1

    if ((aantal/8) * keer) > compleet:
        aantalLampjes = keer - 1

    if ((aantal/8) * keer) == compleet:
        aantalLampjes = keer

uit = 8 - aantalLampjes

GPIO.setup( data_pin, GPIO.OUT )
GPIO.setup( shift_clock_pin, GPIO.OUT )
GPIO.setup( latch_clock_pin, GPIO.OUT )

for i in range(8):
    GPIO.output( data_pin, GPIO.LOW )
    GPIO.output( shift_clock_pin, GPIO.HIGH )
    GPIO.output( shift_clock_pin, GPIO.LOW )

for i in range(uit):
    GPIO.output( data_pin, GPIO.LOW )
    GPIO.output( shift_clock_pin, GPIO.HIGH )
    GPIO.output( shift_clock_pin, GPIO.LOW )

for i in range(aantalLampjes):
    GPIO.output( data_pin, GPIO.HIGH )
    GPIO.output( shift_clock_pin, GPIO.HIGH )
    GPIO.output( shift_clock_pin, GPIO.LOW )

GPIO.output(latch_clock_pin, GPIO.HIGH)
GPIO.output( latch_clock_pin, GPIO.LOW )
