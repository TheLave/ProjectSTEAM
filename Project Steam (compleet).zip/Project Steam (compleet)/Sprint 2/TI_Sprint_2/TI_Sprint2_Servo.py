import json
import urllib.request
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(0)

with urllib.request.urlopen(
        "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=948437B690B388BBEFF1D07D68AB2553&steamids=76561198185415022") as url:
    rawData = json.loads(url.read().decode())
    data = rawData["response"]["players"]

servo = 25
GPIO.setup(servo, GPIO.OUT)


def pulse(pin, delay1, delay2):
    GPIO.output(pin, GPIO.HIGH)
    time.sleep(delay1)
    GPIO.output(pin, GPIO.LOW)
    time.sleep(delay2)


def servo_pulse(pin_nr, position):
    """
    Send a servo pulse on the specified gpio pin
    that causes the servo to turn to the specified position, and
    then waits 20 ms.

    The position must be in the range 0 .. 100.
    For this range, the pulse must be in the range 0.5 ms .. 2.5 ms

    Before this function is called,
    the gpio pin must be configured as output.
    """
    delay = 0.0005 + (0.00002 * position)

    pulse(pin_nr, delay, 0.02)


if data[0]['personastate'] == 0:
    print('offline links')
    for i in range(0, 30, 1):
        servo_pulse(servo, 100)

elif data[0]['personastate'] in [1, 5, 6]:
    print('online rechts')
    for i in range(0, 30, 1):
        servo_pulse(servo, 0)

elif data[0]['personastate'] in [2, 3, 4]:
    print('away midden')
    servo_pulse(servo, 50)
