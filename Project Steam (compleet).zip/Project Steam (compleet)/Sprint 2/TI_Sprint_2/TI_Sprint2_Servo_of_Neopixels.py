import json
import urllib.request
import time
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(0)

print("neopixels walk")

clock_pin = 19
data_pin = 26
nummertjes = []
data = []
byte0 = [0, 0, 0, 0, 0, 0, 0, 0]
byte1 = [1, 1, 1, 1, 1, 1, 1, 1]

GPIO.setup(clock_pin, GPIO.OUT)
GPIO.setup(data_pin, GPIO.OUT)


def apa102_send_bytes(clock_pin, data_pin, bytes):
    """
    zend de bytes naar de APA102 LED strip die is aangesloten op de clock_pin en data_pin
    """

    # zend iedere byte in bytes:
    for byte in bytes:

        # zend ieder bit in byte:
        for bits in byte:

            # maak de data pin hoog als het bit 1 is, laag als het 0 is
            if bits == 1:
                GPIO.output(data_pin, GPIO.HIGH)

            else:
                GPIO.output(data_pin, GPIO.LOW)

            # maak de clock pin hoog
            GPIO.output(clock_pin, GPIO.HIGH)

            # maak de clock pin laag
            GPIO.output(clock_pin, GPIO.LOW)


def apa102(clock_pin, data_pin, color):
    """
    zend de colors naar de APA102 LED strip die is aangesloten op de clock_pin en data_pin

    De colors moet een list zijn, met ieder list element een list van 3 integers,
    in de volgorde [ blauw, groen, rood ].
    Iedere kleur moet in de range 0..255 zijn, 0 voor uit, 255 voor vol aan.

    bv: colors = [ [ 0, 0, 0 ], [ 255, 255, 255 ], [ 128, 0, 0 ] ]
    zet de eerste LED uit, de tweede vol aan (wit) en de derde op blauw, halve strekte.
    """

    # implementeer deze functie, maak gebruik van de apa102_send_bytes functie

    # zend eerst 4 bytes met nullen
    for byte in range(4):
        byte = 8

        for bits in range(byte):
            apa102_send_bytes(clock_pin, data_pin, [byte0])

    # zend dan voor iedere pixel:
    for i in range(8):
        #    eerste een byte met allemaal enen
        for bits in range(1):
            apa102_send_bytes(clock_pin, data_pin, [byte1])

        #    dan de 3 bytes met de kleurwaarden

        for value in color:

            if value == 0:
                for i in range(8):
                    nummertjes.append(0)

            while value >= 1:

                if (value % 2) == 1:
                    nummertjes.append(1)

                else:
                    nummertjes.append(0)

                value = value // 2

            while len(nummertjes) < 8:
                nummertjes.append(0)

            nummertjes.reverse()
            data.append(nummertjes)
            apa102_send_bytes(clock_pin, data_pin, data)
            nummertjes.clear()
            data.clear()

    # zend nog 4 bytes, maar nu met allemaal enen
    for byte in range(4):
        byte = 8

        for bits in range(byte):
            apa102_send_bytes(clock_pin, data_pin, [byte1])


with urllib.request.urlopen(
        "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=948437B690B388BBEFF1D07D68AB2553&steamids=76561198185415022") as url:
    rawData = json.loads(url.read().decode())
    dataSpel = rawData["response"]["players"]

blue = [255, 0, 0]
green = [0, 255, 0]
red = [0, 0, 255]
yellow = [0, 146, 190]
orange = [0, 106, 255]
pink = [50, 50, 200]
purple = [200, 0, 100]

if dataSpel[0]['personastate'] == 0:
    print('offline rood')
    apa102(clock_pin, data_pin, red)

elif dataSpel[0]['personastate'] == 1:
    print('online groen')
    apa102(clock_pin, data_pin, green)

elif dataSpel[0]['personastate'] == 2:
    print('busy geel')
    apa102(clock_pin, data_pin, yellow)

elif dataSpel[0]['personastate'] == 3:
    print('away orange')
    apa102(clock_pin, data_pin, orange)

elif dataSpel[0]['personastate'] == 4:
    print('snooze roze')
    apa102(clock_pin, data_pin, pink)

elif dataSpel[0]['personastate'] == 5:
    print('Looking to trade paars')
    apa102(clock_pin, data_pin, purple)

elif dataSpel[0]['personastate'] == 6:
    print('Looking to play blauw')
    apa102(clock_pin, data_pin, blue)
